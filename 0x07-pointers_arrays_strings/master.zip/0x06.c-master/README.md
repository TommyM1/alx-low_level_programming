# My primary goal of hacking was the intellectual curiosity, the seduction of adventure

Create a file that contains the password for the `crackme2` executable.

- Your file should contain the exact password, no new line, no extra space
- `ltrace`, `ldd`, `gdb` and `objdump` can help
